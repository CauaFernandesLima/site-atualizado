// js/script.test.js

const { validatePassword, validateAge, validateForm } = require('./script');

// Função de alerta simulada para testes
const mockAlert = jest.fn();

describe('Validação de Senha', () => {
    test('Senha válida e coincidente', () => {
        const resultado = validatePassword('Senha@123', 'Senha@123', mockAlert);
        expect(resultado).toBe(true);
        expect(mockAlert).not.toHaveBeenCalled();
    });

    test('Senha inválida', () => {
        const resultado = validatePassword('senha', 'senha', mockAlert);
        expect(resultado).toBe(false); // Alterado para false, pois a validação falha
        expect(mockAlert).toHaveBeenCalledWith("A senha deve ter pelo menos 8 caracteres, incluindo uma letra maiúscula, uma letra minúscula, um número e um caractere especial.");
    });

    test('Senhas não coincidem', () => {
        const resultado = validatePassword('Senha@123', 'Senha@124', mockAlert);
        expect(resultado).toBe(false); // Alterado para false, pois as senhas não coincidem
        expect(mockAlert).toHaveBeenCalledWith("As senhas não coincidem.");
    });
});

describe('Validação de Idade', () => {
    test('Idade menor que 18 anos', () => {
        const resultado = validateAge("2005-08-01", mockAlert);
        expect(resultado).toBe(false); // Alterado para false, pois a idade é menor que 18 anos
        expect(mockAlert).toHaveBeenCalledWith("Você deve ter pelo menos 18 anos para enviar o formulário.");
    });

    test('Idade maior ou igual a 18 anos', () => {
        const resultado = validateAge("2000-01-01", mockAlert);
        expect(resultado).toBe(true);
        expect(mockAlert).not.toHaveBeenCalled();
    });
});

