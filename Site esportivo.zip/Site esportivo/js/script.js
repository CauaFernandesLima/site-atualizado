// js/script.js

/**
 * Obtém os valores dos campos de entrada do formulário.
 * @returns {Object} Um objeto contendo os valores dos campos: senha, confirmarSenha e nascimento.
 */
function getFormInputs() {
    return {
        senha: document.getElementById("senha").value,
        confirmarSenha: document.getElementById("confirmar-senha").value,
        nascimento: document.getElementById("nascimento").value
    };
}
module.exports={validateAge,validatePassword,validatePasswordCharacters}
/**
 * Valida a senha com base em um padrão de regex.
 * @param {string} senha - A senha a ser validada.
 * @returns {string|boolean} Uma mensagem de erro se a senha for inválida, ou `true` se válida.
 */
function validatePasswordCharacters(senha) {
    const senhaRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!senha.match(senhaRegex)) {
        return "A senha deve ter pelo menos 8 caracteres, incluindo uma letra maiúscula, uma letra minúscula, um número e um caractere especial.";
    }
    return true;
}

/**
 * Valida a senha e a confirmação de senha, e verifica se são iguais.
 * @param {string} senha - A senha a ser validada.
 * @param {string} confirmarSenha - A confirmação da senha a ser verificada.
 * @param {Function} alertFunc - Função para exibir alertas (opcional).
 * @returns {boolean} Retorna `true` se a senha for válida e as senhas coincidirem; caso contrário, retorna `false` e exibe uma mensagem de alerta.
 */
function validatePassword(senha, confirmarSenha, alertFunc = () => {}) {
    // Validar a senha
    const passwordValidationResult = validatePasswordCharacters(senha);
    if (passwordValidationResult !== true) {
        alertFunc(passwordValidationResult);
        return false;
    }

    // Verificar se as senhas coincidem
    if (senha !== confirmarSenha) {
        alertFunc("As senhas não coincidem.");
        return false;
    }

    return true;
}

/**
 * Valida a idade baseada na data de nascimento fornecida.
 * @param {string} nascimento - A data de nascimento no formato 'YYYY-MM-DD'.
 * @param {Function} alertFunc - Função para exibir alertas (opcional).
 * @returns {boolean} Retorna `true` se a idade for maior ou igual a 18 anos; caso contrário, retorna `false` e exibe uma mensagem de alerta.
 */
function validateAge(nascimento, alertFunc = () => {}) {
    const hoje = new Date();
    const dataNascimento = new Date(nascimento);
    let idade = hoje.getFullYear() - dataNascimento.getFullYear();
    const mes = hoje.getMonth() - dataNascimento.getMonth();

    if (mes < 0 || (mes === 0 && hoje.getDate() < dataNascimento.getDate())) {
        idade--;
    }

    if (idade < 18) {
        alertFunc("Você deve ter pelo menos 18 anos para enviar o formulário.");
        return false;
    }

    return true;
}

